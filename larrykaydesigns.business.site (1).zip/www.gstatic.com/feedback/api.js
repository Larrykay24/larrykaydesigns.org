(function() {
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    'use strict';
    var p;

    function aa(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    }
    var ba = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
        if (a == Array.prototype || a == Object.prototype) return a;
        a[b] = c.value;
        return a
    };

    function ca(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    }
    var q = ca(this);

    function r(a, b) {
        if (b) a: {
            var c = q;a = a.split(".");
            for (var d = 0; d < a.length - 1; d++) {
                var e = a[d];
                if (!(e in c)) break a;
                c = c[e]
            }
            a = a[a.length - 1];d = c[a];b = b(d);b != d && null != b && ba(c, a, {
                configurable: !0,
                writable: !0,
                value: b
            })
        }
    }
    r("Symbol", function(a) {
        function b(g) {
            if (this instanceof b) throw new TypeError("Symbol is not a constructor");
            return new c(d + (g || "") + "_" + e++, g)
        }

        function c(g, f) {
            this.g = g;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: f
            })
        }
        if (a) return a;
        c.prototype.toString = function() {
            return this.g
        };
        var d = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_",
            e = 0;
        return b
    });
    r("Symbol.iterator", function(a) {
        if (a) return a;
        a = Symbol("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = q[b[c]];
            "function" === typeof d && "function" != typeof d.prototype[a] && ba(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return da(aa(this))
                }
            })
        }
        return a
    });

    function da(a) {
        a = {
            next: a
        };
        a[Symbol.iterator] = function() {
            return this
        };
        return a
    }

    function ea(a) {
        return a.raw = a
    }

    function u(a) {
        var b = "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
        if (b) return b.call(a);
        if ("number" == typeof a.length) return {
            next: aa(a)
        };
        throw Error(String(a) + " is not an iterable or ArrayLike");
    }
    var fa = "function" == typeof Object.create ? Object.create : function(a) {
            function b() {}
            b.prototype = a;
            return new b
        },
        ha;
    if ("function" == typeof Object.setPrototypeOf) ha = Object.setPrototypeOf;
    else {
        var ia;
        a: {
            var ja = {
                    a: !0
                },
                ka = {};
            try {
                ka.__proto__ = ja;
                ia = ka.a;
                break a
            } catch (a) {}
            ia = !1
        }
        ha = ia ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var la = ha;

    function ma(a, b) {
        a.prototype = fa(b.prototype);
        a.prototype.constructor = a;
        if (la) la(a, b);
        else
            for (var c in b)
                if ("prototype" != c)
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.S = b.prototype
    }

    function na() {
        this.m = !1;
        this.h = null;
        this.i = void 0;
        this.g = 1;
        this.u = 0;
        this.j = null
    }

    function oa(a) {
        if (a.m) throw new TypeError("Generator is already running");
        a.m = !0
    }
    na.prototype.s = function(a) {
        this.i = a
    };

    function pa(a, b) {
        a.j = {
            aa: b,
            ba: !0
        };
        a.g = a.u
    }
    na.prototype.return = function(a) {
        this.j = {
            return: a
        };
        this.g = this.u
    };

    function v(a, b, c) {
        a.g = c;
        return {
            value: b
        }
    }

    function qa(a) {
        this.g = new na;
        this.h = a
    }

    function ra(a, b) {
        oa(a.g);
        var c = a.g.h;
        if (c) return sa(a, "return" in c ? c["return"] : function(d) {
            return {
                value: d,
                done: !0
            }
        }, b, a.g.return);
        a.g.return(b);
        return x(a)
    }

    function sa(a, b, c, d) {
        try {
            var e = b.call(a.g.h, c);
            if (!(e instanceof Object)) throw new TypeError("Iterator result " + e + " is not an object");
            if (!e.done) return a.g.m = !1, e;
            var g = e.value
        } catch (f) {
            return a.g.h = null, pa(a.g, f), x(a)
        }
        a.g.h = null;
        d.call(a.g, g);
        return x(a)
    }

    function x(a) {
        for (; a.g.g;) try {
            var b = a.h(a.g);
            if (b) return a.g.m = !1, {
                value: b.value,
                done: !1
            }
        } catch (c) {
            a.g.i = void 0, pa(a.g, c)
        }
        a.g.m = !1;
        if (a.g.j) {
            b = a.g.j;
            a.g.j = null;
            if (b.ba) throw b.aa;
            return {
                value: b.return,
                done: !0
            }
        }
        return {
            value: void 0,
            done: !0
        }
    }

    function ta(a) {
        this.next = function(b) {
            oa(a.g);
            a.g.h ? b = sa(a, a.g.h.next, b, a.g.s) : (a.g.s(b), b = x(a));
            return b
        };
        this.throw = function(b) {
            oa(a.g);
            a.g.h ? b = sa(a, a.g.h["throw"], b, a.g.s) : (pa(a.g, b), b = x(a));
            return b
        };
        this.return = function(b) {
            return ra(a, b)
        };
        this[Symbol.iterator] = function() {
            return this
        }
    }

    function ua(a) {
        function b(d) {
            return a.next(d)
        }

        function c(d) {
            return a.throw(d)
        }
        return new Promise(function(d, e) {
            function g(f) {
                f.done ? d(f.value) : Promise.resolve(f.value).then(b, c).then(g, e)
            }
            g(a.next())
        })
    }

    function y(a) {
        return ua(new ta(new qa(a)))
    }

    function va() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    }
    r("Promise", function(a) {
        function b(f) {
            this.g = 0;
            this.i = void 0;
            this.h = [];
            this.u = !1;
            var h = this.j();
            try {
                f(h.resolve, h.reject)
            } catch (k) {
                h.reject(k)
            }
        }

        function c() {
            this.g = null
        }

        function d(f) {
            return f instanceof b ? f : new b(function(h) {
                h(f)
            })
        }
        if (a) return a;
        c.prototype.h = function(f) {
            if (null == this.g) {
                this.g = [];
                var h = this;
                this.i(function() {
                    h.m()
                })
            }
            this.g.push(f)
        };
        var e = q.setTimeout;
        c.prototype.i = function(f) {
            e(f, 0)
        };
        c.prototype.m = function() {
            for (; this.g && this.g.length;) {
                var f = this.g;
                this.g = [];
                for (var h = 0; h < f.length; ++h) {
                    var k =
                        f[h];
                    f[h] = null;
                    try {
                        k()
                    } catch (l) {
                        this.j(l)
                    }
                }
            }
            this.g = null
        };
        c.prototype.j = function(f) {
            this.i(function() {
                throw f;
            })
        };
        b.prototype.j = function() {
            function f(l) {
                return function(m) {
                    k || (k = !0, l.call(h, m))
                }
            }
            var h = this,
                k = !1;
            return {
                resolve: f(this.G),
                reject: f(this.m)
            }
        };
        b.prototype.G = function(f) {
            if (f === this) this.m(new TypeError("A Promise cannot resolve to itself"));
            else if (f instanceof b) this.I(f);
            else {
                a: switch (typeof f) {
                    case "object":
                        var h = null != f;
                        break a;
                    case "function":
                        h = !0;
                        break a;
                    default:
                        h = !1
                }
                h ? this.C(f) : this.s(f)
            }
        };
        b.prototype.C = function(f) {
            var h = void 0;
            try {
                h = f.then
            } catch (k) {
                this.m(k);
                return
            }
            "function" == typeof h ? this.J(h, f) : this.s(f)
        };
        b.prototype.m = function(f) {
            this.B(2, f)
        };
        b.prototype.s = function(f) {
            this.B(1, f)
        };
        b.prototype.B = function(f, h) {
            if (0 != this.g) throw Error("Cannot settle(" + f + ", " + h + "): Promise already settled in state" + this.g);
            this.g = f;
            this.i = h;
            2 === this.g && this.H();
            this.D()
        };
        b.prototype.H = function() {
            var f = this;
            e(function() {
                if (f.F()) {
                    var h = q.console;
                    "undefined" !== typeof h && h.error(f.i)
                }
            }, 1)
        };
        b.prototype.F =
            function() {
                if (this.u) return !1;
                var f = q.CustomEvent,
                    h = q.Event,
                    k = q.dispatchEvent;
                if ("undefined" === typeof k) return !0;
                "function" === typeof f ? f = new f("unhandledrejection", {
                    cancelable: !0
                }) : "function" === typeof h ? f = new h("unhandledrejection", {
                    cancelable: !0
                }) : (f = q.document.createEvent("CustomEvent"), f.initCustomEvent("unhandledrejection", !1, !0, f));
                f.promise = this;
                f.reason = this.i;
                return k(f)
            };
        b.prototype.D = function() {
            if (null != this.h) {
                for (var f = 0; f < this.h.length; ++f) g.h(this.h[f]);
                this.h = null
            }
        };
        var g = new c;
        b.prototype.I =
            function(f) {
                var h = this.j();
                f.L(h.resolve, h.reject)
            };
        b.prototype.J = function(f, h) {
            var k = this.j();
            try {
                f.call(h, k.resolve, k.reject)
            } catch (l) {
                k.reject(l)
            }
        };
        b.prototype.then = function(f, h) {
            function k(t, w) {
                return "function" == typeof t ? function(M) {
                    try {
                        l(t(M))
                    } catch (z) {
                        m(z)
                    }
                } : w
            }
            var l, m, n = new b(function(t, w) {
                l = t;
                m = w
            });
            this.L(k(f, l), k(h, m));
            return n
        };
        b.prototype.catch = function(f) {
            return this.then(void 0, f)
        };
        b.prototype.L = function(f, h) {
            function k() {
                switch (l.g) {
                    case 1:
                        f(l.i);
                        break;
                    case 2:
                        h(l.i);
                        break;
                    default:
                        throw Error("Unexpected state: " +
                            l.g);
                }
            }
            var l = this;
            null == this.h ? g.h(k) : this.h.push(k);
            this.u = !0
        };
        b.resolve = d;
        b.reject = function(f) {
            return new b(function(h, k) {
                k(f)
            })
        };
        b.race = function(f) {
            return new b(function(h, k) {
                for (var l = u(f), m = l.next(); !m.done; m = l.next()) d(m.value).L(h, k)
            })
        };
        b.all = function(f) {
            var h = u(f),
                k = h.next();
            return k.done ? d([]) : new b(function(l, m) {
                function n(M) {
                    return function(z) {
                        t[M] = z;
                        w--;
                        0 == w && l(t)
                    }
                }
                var t = [],
                    w = 0;
                do t.push(void 0), w++, d(k.value).L(n(t.length - 1), m), k = h.next(); while (!k.done)
            })
        };
        return b
    });
    r("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            a: {
                var d = this;d instanceof String && (d = String(d));
                for (var e = d.length, g = 0; g < e; g++) {
                    var f = d[g];
                    if (b.call(c, f, g, d)) {
                        b = f;
                        break a
                    }
                }
                b = void 0
            }
            return b
        }
    });

    function A(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    }
    r("WeakMap", function(a) {
        function b(k) {
            this.g = (h += Math.random() + 1).toString();
            if (k) {
                k = u(k);
                for (var l; !(l = k.next()).done;) l = l.value, this.set(l[0], l[1])
            }
        }

        function c() {}

        function d(k) {
            var l = typeof k;
            return "object" === l && null !== k || "function" === l
        }

        function e(k) {
            if (!A(k, f)) {
                var l = new c;
                ba(k, f, {
                    value: l
                })
            }
        }

        function g(k) {
            var l = Object[k];
            l && (Object[k] = function(m) {
                if (m instanceof c) return m;
                Object.isExtensible(m) && e(m);
                return l(m)
            })
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var k = Object.seal({}),
                        l = Object.seal({}),
                        m = new a([
                            [k, 2],
                            [l, 3]
                        ]);
                    if (2 != m.get(k) || 3 != m.get(l)) return !1;
                    m.delete(k);
                    m.set(l, 4);
                    return !m.has(k) && 4 == m.get(l)
                } catch (n) {
                    return !1
                }
            }()) return a;
        var f = "$jscomp_hidden_" + Math.random();
        g("freeze");
        g("preventExtensions");
        g("seal");
        var h = 0;
        b.prototype.set = function(k, l) {
            if (!d(k)) throw Error("Invalid WeakMap key");
            e(k);
            if (!A(k, f)) throw Error("WeakMap key fail: " + k);
            k[f][this.g] = l;
            return this
        };
        b.prototype.get = function(k) {
            return d(k) && A(k, f) ? k[f][this.g] : void 0
        };
        b.prototype.has = function(k) {
            return d(k) && A(k,
                f) && A(k[f], this.g)
        };
        b.prototype.delete = function(k) {
            return d(k) && A(k, f) && A(k[f], this.g) ? delete k[f][this.g] : !1
        };
        return b
    });
    r("Map", function(a) {
        function b() {
            var h = {};
            return h.v = h.next = h.head = h
        }

        function c(h, k) {
            var l = h.g;
            return da(function() {
                if (l) {
                    for (; l.head != h.g;) l = l.v;
                    for (; l.next != l.head;) return l = l.next, {
                        done: !1,
                        value: k(l)
                    };
                    l = null
                }
                return {
                    done: !0,
                    value: void 0
                }
            })
        }

        function d(h, k) {
            var l = k && typeof k;
            "object" == l || "function" == l ? g.has(k) ? l = g.get(k) : (l = "" + ++f, g.set(k, l)) : l = "p_" + k;
            var m = h.h[l];
            if (m && A(h.h, l))
                for (h = 0; h < m.length; h++) {
                    var n = m[h];
                    if (k !== k && n.key !== n.key || k === n.key) return {
                        id: l,
                        list: m,
                        index: h,
                        o: n
                    }
                }
            return {
                id: l,
                list: m,
                index: -1,
                o: void 0
            }
        }

        function e(h) {
            this.h = {};
            this.g = b();
            this.size = 0;
            if (h) {
                h = u(h);
                for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
            }
        }
        if (function() {
                if (!a || "function" != typeof a || !a.prototype.entries || "function" != typeof Object.seal) return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(u([
                            [h, "s"]
                        ]));
                    if ("s" != k.get(h) || 1 != k.size || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || 2 != k.size) return !1;
                    var l = k.entries(),
                        m = l.next();
                    if (m.done || m.value[0] != h || "s" != m.value[1]) return !1;
                    m = l.next();
                    return m.done || 4 != m.value[0].x ||
                        "t" != m.value[1] || !l.next().done ? !1 : !0
                } catch (n) {
                    return !1
                }
            }()) return a;
        var g = new WeakMap;
        e.prototype.set = function(h, k) {
            h = 0 === h ? 0 : h;
            var l = d(this, h);
            l.list || (l.list = this.h[l.id] = []);
            l.o ? l.o.value = k : (l.o = {
                next: this.g,
                v: this.g.v,
                head: this.g,
                key: h,
                value: k
            }, l.list.push(l.o), this.g.v.next = l.o, this.g.v = l.o, this.size++);
            return this
        };
        e.prototype.delete = function(h) {
            h = d(this, h);
            return h.o && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this.h[h.id], h.o.v.next = h.o.next, h.o.next.v = h.o.v, h.o.head = null, this.size--, !0) : !1
        };
        e.prototype.clear = function() {
            this.h = {};
            this.g = this.g.v = b();
            this.size = 0
        };
        e.prototype.has = function(h) {
            return !!d(this, h).o
        };
        e.prototype.get = function(h) {
            return (h = d(this, h).o) && h.value
        };
        e.prototype.entries = function() {
            return c(this, function(h) {
                return [h.key, h.value]
            })
        };
        e.prototype.keys = function() {
            return c(this, function(h) {
                return h.key
            })
        };
        e.prototype.values = function() {
            return c(this, function(h) {
                return h.value
            })
        };
        e.prototype.forEach = function(h, k) {
            for (var l = this.entries(), m; !(m = l.next()).done;) m = m.value,
                h.call(k, m[1], m[0], this)
        };
        e.prototype[Symbol.iterator] = e.prototype.entries;
        var f = 0;
        return e
    });
    r("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) A(b, d) && c.push(b[d]);
            return c
        }
    });
    r("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c
        }
    });
    r("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
                var g = d[c];
                if (g === b || Object.is(g, b)) return !0
            }
            return !1
        }
    });
    r("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            if (null == this) throw new TypeError("The 'this' value for String.prototype.includes must not be null or undefined");
            if (b instanceof RegExp) throw new TypeError("First argument to String.prototype.includes must not be a regular expression");
            return -1 !== (this + "").indexOf(b, c || 0)
        }
    });
    r("Number.isNaN", function(a) {
        return a ? a : function(b) {
            return "number" === typeof b && isNaN(b)
        }
    });

    function wa(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var g = c++;
                        return {
                            value: b(g, a[g]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[Symbol.iterator] = function() {
            return e
        };
        return e
    }
    r("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return wa(this, function(b, c) {
                return [b, c]
            })
        }
    });
    r("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return wa(this, function(b) {
                return b
            })
        }
    });
    r("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = null != c ? c : function(h) {
                return h
            };
            var e = [],
                g = "undefined" != typeof Symbol && Symbol.iterator && b[Symbol.iterator];
            if ("function" == typeof g) {
                b = g.call(b);
                for (var f = 0; !(g = b.next()).done;) e.push(c.call(d, g.value, f++))
            } else
                for (g = b.length, f = 0; f < g; f++) e.push(c.call(d, b[f], f));
            return e
        }
    });
    r("Array.prototype.values", function(a) {
        return a ? a : function() {
            return wa(this, function(b, c) {
                return c
            })
        }
    });
    var xa = "function" == typeof Object.assign ? Object.assign : function(a, b) {
        for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d)
                for (var e in d) A(d, e) && (a[e] = d[e])
        }
        return a
    };
    r("Object.assign", function(a) {
        return a || xa
    });
    r("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) A(b, d) && c.push([d, b[d]]);
            return c
        }
    });
    r("String.prototype.replaceAll", function(a) {
        return a ? a : function(b, c) {
            if (b instanceof RegExp && !b.global) throw new TypeError("String.prototype.replaceAll called with a non-global RegExp argument.");
            return b instanceof RegExp ? this.replace(b, c) : this.replace(new RegExp(String(b).replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g, "\\$1").replace(/\x08/g, "\\x08"), "g"), c)
        }
    });
    var ya = ya || {},
        B = this || self;

    function za(a, b) {
        a = a.split(".");
        b = b || B;
        for (var c = 0; c < a.length; c++)
            if (b = b[a[c]], null == b) return null;
        return b
    }

    function Aa(a) {
        var b = typeof a;
        b = "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null";
        return "array" == b || "object" == b && "number" == typeof a.length
    }

    function Ba(a) {
        var b = typeof a;
        return "object" == b && null != a || "function" == b
    }

    function Ca(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function Da(a, b, c) {
        if (!a) throw Error();
        if (2 < arguments.length) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    }

    function C(a, b, c) {
        C = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? Ca : Da;
        return C.apply(null, arguments)
    }

    function Ea(a, b) {
        function c() {}
        c.prototype = b.prototype;
        a.S = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a;
        a.oa = function(d, e, g) {
            for (var f = Array(arguments.length - 2), h = 2; h < arguments.length; h++) f[h - 2] = arguments[h];
            return b.prototype[e].apply(d, f)
        }
    }

    function Fa(a) {
        return a
    };
    var Ga;
    var Ha, Ia = za("CLOSURE_FLAGS"),
        Ja = Ia && Ia[610401301];
    Ha = null != Ja ? Ja : !1;

    function Ka() {
        var a = B.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var D, La = B.navigator;
    D = La ? La.userAgentData || null : null;

    function Ma(a) {
        return Ha ? D ? D.brands.some(function(b) {
            return (b = b.brand) && -1 != b.indexOf(a)
        }) : !1 : !1
    }

    function E(a) {
        return -1 != Ka().indexOf(a)
    };

    function F() {
        return Ha ? !!D && 0 < D.brands.length : !1
    }

    function Na() {
        return F() ? Ma("Chromium") : (E("Chrome") || E("CriOS")) && !(F() ? 0 : E("Edge")) || E("Silk")
    };
    var Oa = Array.prototype.indexOf ? function(a, b) {
            return Array.prototype.indexOf.call(a, b, void 0)
        } : function(a, b) {
            if ("string" === typeof a) return "string" !== typeof b || 1 != b.length ? -1 : a.indexOf(b, 0);
            for (var c = 0; c < a.length; c++)
                if (c in a && a[c] === b) return c;
            return -1
        },
        Pa = Array.prototype.forEach ? function(a, b) {
            Array.prototype.forEach.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
        };

    function Qa(a, b) {
        b = Oa(a, b);
        var c;
        (c = 0 <= b) && Array.prototype.splice.call(a, b, 1);
        return c
    }

    function Ra(a) {
        var b = a.length;
        if (0 < b) {
            for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };
    var Sa = F() ? !1 : E("Trident") || E("MSIE"),
        Ta = -1 != Ka().toLowerCase().indexOf("webkit") && !E("Edge") && E("Mobile");
    !E("Android") || Na();
    Na();
    E("Safari") && (Na() || (F() ? 0 : E("Coast")) || (F() ? 0 : E("Opera")) || (F() ? 0 : E("Edge")) || (F() ? Ma("Microsoft Edge") : E("Edg/")) || F() && Ma("Opera"));
    var Ua = {},
        G = null;

    function Va(a) {
        var b = a.length,
            c = 3 * b / 4;
        c % 3 ? c = Math.floor(c) : -1 != "=.".indexOf(a[b - 1]) && (c = -1 != "=.".indexOf(a[b - 2]) ? c - 2 : c - 1);
        var d = new Uint8Array(c),
            e = 0;
        Wa(a, function(g) {
            d[e++] = g
        });
        return e !== c ? d.subarray(0, e) : d
    }

    function Wa(a, b) {
        function c(k) {
            for (; d < a.length;) {
                var l = a.charAt(d++),
                    m = G[l];
                if (null != m) return m;
                if (!/^[\s\xa0]*$/.test(l)) throw Error("Unknown base64 encoding at char: " + l);
            }
            return k
        }
        Xa();
        for (var d = 0;;) {
            var e = c(-1),
                g = c(0),
                f = c(64),
                h = c(64);
            if (64 === h && -1 === e) break;
            b(e << 2 | g >> 4);
            64 != f && (b(g << 4 & 240 | f >> 2), 64 != h && b(f << 6 & 192 | h))
        }
    }

    function Xa() {
        if (!G) {
            G = {};
            for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++) {
                var d = a.concat(b[c].split(""));
                Ua[c] = d;
                for (var e = 0; e < d.length; e++) {
                    var g = d[e];
                    void 0 === G[g] && (G[g] = e)
                }
            }
        }
    };
    var Ya = "undefined" !== typeof Uint8Array,
        Za = !Sa && "function" === typeof btoa,
        $a = /[-_.]/g,
        ab = {
            "-": "+",
            _: "/",
            ".": "="
        };

    function bb(a) {
        return ab[a] || ""
    }

    function cb(a) {
        return Ya && null != a && a instanceof Uint8Array
    };
    var H = "function" === typeof Symbol && "symbol" === typeof Symbol() ? Symbol() : void 0,
        db = Math.max,
        eb = db.apply,
        fb = Object.values({
            ka: 1,
            ja: 2,
            ia: 4,
            ma: 8,
            la: 16,
            ea: 32,
            na: 64,
            ga: 128,
            fa: 256,
            ha: 512
        }),
        gb;
    if (fb instanceof Array) gb = fb;
    else {
        for (var hb = u(fb), ib, jb = []; !(ib = hb.next()).done;) jb.push(ib.value);
        gb = jb
    }
    eb.call(db, Math, gb);
    var kb = H ? function(a, b) {
        a[H] |= b
    } : function(a, b) {
        void 0 !== a.g ? a.g |= b : Object.defineProperties(a, {
            g: {
                value: b,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        })
    };

    function lb(a) {
        var b = I(a);
        1 !== (b & 1) && (Object.isFrozen(a) && (a = Array.prototype.slice.call(a)), J(a, b | 1))
    }
    var I = H ? function(a) {
            return a[H] | 0
        } : function(a) {
            return a.g | 0
        },
        K = H ? function(a) {
            return a[H]
        } : function(a) {
            return a.g
        },
        J = H ? function(a, b) {
            a[H] = b
        } : function(a, b) {
            void 0 !== a.g ? a.g = b : Object.defineProperties(a, {
                g: {
                    value: b,
                    configurable: !0,
                    writable: !0,
                    enumerable: !1
                }
            })
        };

    function mb() {
        var a = [];
        kb(a, 1);
        return a
    }

    function nb(a, b) {
        J(b, (a | 0) & -51)
    }

    function ob(a, b) {
        J(b, (a | 18) & -41)
    }

    function pb(a) {
        a = a >> 10 & 1023;
        return 0 === a ? 536870912 : a
    };
    var L = {};

    function N(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    }

    function qb(a, b, c) {
        if (!Array.isArray(a) || a.length) return !1;
        var d = I(a);
        if (d & 1) return !0;
        if (!b || !b.includes(c)) return !1;
        J(a, d | 1);
        return !0
    }
    var O, rb = [];
    J(rb, 23);
    O = Object.freeze(rb);

    function sb(a) {
        return a.displayName || a.name || "unknown type name"
    };

    function tb(a, b, c) {
        a = a || {};
        b = b || {};
        var d = {},
            e;
        for (e in a) d[e] = 0;
        for (var g in b) d[g] = 0;
        for (var f in d)
            if (!isNaN(f) && !ub(f, a[f], f, b[f], c, 0)) return !1;
        return !0
    }

    function vb(a, b) {
        if ("string" === typeof b) try {
            var c = b;
            if (Za) {
                $a.test(c) && (c = c.replace($a, bb));
                var d = atob(c);
                var e = new Uint8Array(d.length);
                for (c = 0; c < d.length; c++) e[c] = d.charCodeAt(c);
                b = e
            } else b = Va(c)
        } catch (g) {
            return !1
        }
        if (d = cb(b)) a: if (d = a.length, d !== b.length) d = !1;
            else {
                for (e = 0; e < d; e++)
                    if (a[e] !== b[e]) {
                        d = !1;
                        break a
                    }
                d = !0
            }
        return d
    }

    function wb(a, b) {
        var c = void 0;
        if (a.A === L) {
            var d = a.constructor.W;
            a = a.l;
            c = (K(a) >> 8 & 1) - 1
        }
        b.A === L && (d = d || b.constructor.W, b = b.l, c = null == c ? (K(b) >> 8 & 1) - 1 : c);
        return ub(void 0, a, void 0, b, d, c)
    }

    function ub(a, b, c, d, e, g) {
        g = void 0 === g ? 9999 : g;
        if (b === d || null == b && null == d) return !0;
        if (null == b) return qb(d, e, +a - g);
        if (null == d) return qb(b, e, +c - g);
        if (cb(b)) return vb(b, d);
        if (cb(d)) return vb(d, b);
        a = typeof b;
        c = typeof d;
        if ("object" !== a || "object" !== c) return Number.isNaN(b) || Number.isNaN(d) ? String(b) === String(d) : "string" === a && "number" === c || "number" === a && "string" === c ? +b === +d : "boolean" === a && "number" === c || "number" === a && "boolean" === c ? !b === !d : !1;
        if (b.A === L || d.A === L) return wb(b, d);
        if (b.constructor != d.constructor) return !1;
        if (b.constructor === Array) {
            c = a = void 0;
            for (var f = b.length, h = d.length, k = Math.max(f, h), l = 0; l < k; l++) {
                var m = l >= f ? void 0 : b[l],
                    n = l >= h ? void 0 : d[l];
                m && l == f - 1 && N(m) && (a = m, m = void 0);
                n && l == h - 1 && N(n) && (c = n, n = void 0);
                null == n && qb(m, e, l - g) && (m = void 0);
                null == m && qb(n, e, l - g) && (n = void 0);
                if (!ub(l, m, l, n)) return !1
            }
            return a || c ? tb(a, c, e) : !0
        }
        if (b.constructor === Object) return tb(b, d);
        throw Error();
    };

    function xb(a, b, c, d) {
        if (-1 === c) return null;
        if (c >= pb(b)) {
            if (b & 128) return a[a.length - 1][c]
        } else {
            var e = a.length;
            if (d && b & 128 && (d = a[e - 1][c], null != d)) return d;
            b = c + ((b >> 8 & 1) - 1);
            if (b < e) return a[b]
        }
    }

    function yb(a, b, c, d, e) {
        var g = pb(b);
        if (c >= g || e) {
            e = b;
            if (b & 128) g = a[a.length - 1];
            else {
                if (null == d) return;
                g = a[g + ((b >> 8 & 1) - 1)] = {};
                e |= 128
            }
            g[c] = d;
            e &= -513;
            e !== b && J(a, e)
        } else a[c + ((b >> 8 & 1) - 1)] = d, b & 128 && (d = a[a.length - 1], c in d && delete d[c]), b & 512 && J(a, b & -513)
    }

    function P(a, b, c) {
        c = null == c ? c : !!c;
        var d = a.l,
            e = K(d);
        if (e & 2) throw Error();
        yb(d, e, b, !1 !== c ? c : void 0);
        return a
    }

    function Q(a, b) {
        a = a.l;
        b = xb(a, K(a), b);
        b = null == b ? b : !!b;
        return null != b ? b : !1
    };
    var zb;

    function Ab(a, b) {
        zb = b;
        a = new a(b);
        zb = void 0;
        return a
    }

    function Bb(a, b, c) {
        null == a && (a = zb);
        zb = void 0;
        if (null == a) {
            var d = 48;
            c ? (a = [c], d |= 256) : a = [];
            b && (d = d & -1047553 | (b & 1023) << 10)
        } else {
            if (!Array.isArray(a)) throw Error();
            d = I(a);
            if (d & 32) return a;
            d |= 32;
            if (c && (d |= 256, c !== a[0])) throw Error();
            a: {
                c = a;
                var e = c.length;
                if (e) {
                    var g = e - 1,
                        f = c[g];
                    if (N(f)) {
                        d |= 128;
                        b = (d >> 8 & 1) - 1;
                        e = g - b;
                        1024 <= e && (Cb(c, b, f), e = 1023);
                        d = d & -1047553 | (e & 1023) << 10;
                        break a
                    }
                }
                b && (f = (d >> 8 & 1) - 1, b = Math.max(b, e - f), 1024 < b && (Cb(c, f, {}), d |= 128, b = 1023), d = d & -1047553 | (b & 1023) << 10)
            }
        }
        J(a, d);
        return a
    }

    function Cb(a, b, c) {
        for (var d = 1023 + b, e = a.length, g = d; g < e; g++) {
            var f = a[g];
            null != f && f !== c && (c[g - b] = f)
        }
        a.length = d + 1;
        a[d] = c
    };

    function Db(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (a && !Array.isArray(a) && cb(a)) {
                    if (Za) {
                        for (var b = "", c = 0, d = a.length - 10240; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
                        b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
                        a = btoa(b)
                    } else {
                        void 0 === b && (b = 0);
                        Xa();
                        b = Ua[b];
                        c = Array(Math.floor(a.length / 3));
                        d = b[64] || "";
                        for (var e = 0, g = 0; e < a.length - 2; e += 3) {
                            var f = a[e],
                                h = a[e + 1],
                                k = a[e + 2],
                                l = b[f >> 2];
                            f = b[(f & 3) << 4 | h >> 4];
                            h = b[(h & 15) <<
                                2 | k >> 6];
                            k = b[k & 63];
                            c[g++] = "" + l + f + h + k
                        }
                        l = 0;
                        k = d;
                        switch (a.length - e) {
                            case 2:
                                l = a[e + 1], k = b[(l & 15) << 2] || d;
                            case 1:
                                a = a[e], c[g] = "" + b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
                        }
                        a = c.join("")
                    }
                    return a
                }
        }
        return a
    };

    function Eb(a, b, c) {
        a = Array.prototype.slice.call(a);
        var d = a.length,
            e = b & 128 ? a[d - 1] : void 0;
        d += e ? -1 : 0;
        for (b = b & 256 ? 1 : 0; b < d; b++) a[b] = c(a[b]);
        if (e) {
            b = a[b] = {};
            for (var g in e) b[g] = c(e[g])
        }
        return a
    }

    function Fb(a, b, c, d, e, g) {
        if (null != a) {
            if (Array.isArray(a)) a = e && 0 == a.length && I(a) & 1 ? void 0 : g && I(a) & 2 ? a : Gb(a, b, c, void 0 !== d, e, g);
            else if (N(a)) {
                var f = {},
                    h;
                for (h in a) f[h] = Fb(a[h], b, c, d, e, g);
                a = f
            } else a = b(a, d);
            return a
        }
    }

    function Gb(a, b, c, d, e, g) {
        var f = d || c ? I(a) : 0;
        d = d ? !!(f & 16) : void 0;
        a = Array.prototype.slice.call(a);
        for (var h = 0; h < a.length; h++) a[h] = Fb(a[h], b, c, d, e, g);
        c && c(f, a);
        return a
    }

    function Hb(a) {
        return a.A === L ? a.toJSON() : Db(a)
    };

    function Ib(a, b, c) {
        c = void 0 === c ? ob : c;
        if (null != a) {
            if (Ya && a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = I(a);
                if (d & 2) return a;
                if (b && !(d & 32) && (d & 16 || 0 === d)) return J(a, d | 18), a;
                a = Gb(a, Ib, d & 4 ? ob : c, !0, !1, !0);
                b = I(a);
                b & 4 && b & 2 && Object.freeze(a);
                return a
            }
            if (a.A === L) a: if (b = a.l, c = K(b), !(c & 2)) {
                if (c & 512 && (d = a.U) && wb(d, a)) {
                    a = d;
                    break a
                }
                d = Jb(a, !0);
                a.U = d;
                J(b, c | 512);
                a = d
            }
            return a
        }
    }

    function Jb(a, b) {
        var c = a.l;
        b = Kb(c, K(c), b);
        return Ab(a.constructor, b)
    }

    function Kb(a, b, c) {
        var d = c || b & 2 ? ob : nb,
            e = !!(b & 16);
        a = Eb(a, b, function(g) {
            return Ib(g, e, d)
        });
        kb(a, 16 | (c ? 2 : 0));
        return a
    };

    function R(a, b, c) {
        this.l = Bb(a, b, c)
    }
    R.prototype.toJSON = function() {
        var a = Gb(this.l, Hb, void 0, void 0, !1, !1);
        return Lb(this, a, !0)
    };
    R.prototype.A = L;
    R.prototype.toString = function() {
        return Lb(this, this.l, !1).toString()
    };

    function Lb(a, b, c) {
        var d = a.constructor.W,
            e = pb(K(c ? a.l : b));
        if (d) {
            if (!c) {
                b = Array.prototype.slice.call(b);
                var g;
                if (b.length && N(g = b[b.length - 1]))
                    for (var f = 0; f < d.length; f++)
                        if (d[f] >= e) {
                            Object.assign(b[b.length - 1] = {}, g);
                            break
                        }
            }
            e = b;
            c = !c;
            g = K(a.l);
            a = pb(g);
            g = (g >> 8 & 1) - 1;
            var h;
            for (f = 0; f < d.length; f++) {
                var k = d[f];
                if (k < a) {
                    k += g;
                    var l = e[k];
                    null == l ? e[k] = c ? O : mb() : c && l !== O && lb(l)
                } else h || (l = void 0, e.length && N(l = e[e.length - 1]) ? h = l : e.push(h = {})), l = h[k], null == h[k] ? h[k] = c ? O : mb() : c && l !== O && lb(l)
            }
        }
        return b
    };
    try {
        (new self.OffscreenCanvas(0, 0)).getContext("2d")
    } catch (a) {};
    var Mb = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");

    function Nb(a, b) {
        for (var c, d, e = 1; e < arguments.length; e++) {
            d = arguments[e];
            for (c in d) a[c] = d[c];
            for (var g = 0; g < Mb.length; g++) c = Mb[g], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
        }
    };
    var Ob;

    function Pb(a) {
        this.g = a
    }
    Pb.prototype.toString = function() {
        return this.g + ""
    };
    var Qb = {};

    function Rb(a) {
        if (void 0 === Ob) {
            var b = null;
            var c = B.trustedTypes;
            if (c && c.createPolicy) {
                try {
                    b = c.createPolicy("uf-api#html", {
                        createHTML: Fa,
                        createScript: Fa,
                        createScriptURL: Fa
                    })
                } catch (d) {
                    B.console && B.console.error(d.message)
                }
                Ob = b
            } else Ob = b
        }
        a = (b = Ob) ? b.createScriptURL(a) : a;
        return new Pb(a, Qb)
    };

    function S(a) {
        this.g = a
    }
    S.prototype.toString = function() {
        return this.g.toString()
    };
    var Sb = {},
        Tb = new S("about:invalid#zClosurez", Sb);
    var Ub = /^[\w+/_-]+[=]{0,2}$/;

    function Vb(a) {
        a = (a || B).document;
        return a.querySelector ? (a = a.querySelector("script[nonce]")) && (a = a.nonce || a.getAttribute("nonce")) && Ub.test(a) ? a : "" : ""
    };

    function Wb(a, b, c) {
        function d(h) {
            h && b.appendChild("string" === typeof h ? a.createTextNode(h) : h)
        }
        for (var e = 1; e < c.length; e++) {
            var g = c[e];
            if (!Aa(g) || Ba(g) && 0 < g.nodeType) d(g);
            else {
                a: {
                    if (g && "number" == typeof g.length) {
                        if (Ba(g)) {
                            var f = "function" == typeof g.item || "string" == typeof g.item;
                            break a
                        }
                        if ("function" === typeof g) {
                            f = "function" == typeof g.item;
                            break a
                        }
                    }
                    f = !1
                }
                Pa(f ? Ra(g) : g, d)
            }
        }
    }

    function Xb(a) {
        var b = "SCRIPT";
        "application/xhtml+xml" === a.contentType && (b = b.toLowerCase());
        return a.createElement(b)
    }

    function Yb(a) {
        this.g = a || B.document || document
    }
    Yb.prototype.append = function(a, b) {
        Wb(9 == a.nodeType ? a : a.ownerDocument || a.document, a, arguments)
    };

    function T() {
        this.m = this.m;
        this.u = this.u
    }
    T.prototype.m = !1;
    T.prototype.isDisposed = function() {
        return this.m
    };
    T.prototype.K = function() {
        if (this.u)
            for (; this.u.length;) this.u.shift()()
    };

    function Zb(a, b) {
        this.type = a;
        this.g = this.target = b;
        this.defaultPrevented = !1
    };
    var $b = "closure_listenable_" + (1E6 * Math.random() | 0);
    var ac = 0;

    function bc(a, b, c, d, e) {
        this.listener = a;
        this.proxy = null;
        this.src = b;
        this.type = c;
        this.capture = !!d;
        this.R = e;
        this.key = ++ac;
        this.M = this.P = !1
    }

    function cc(a) {
        a.M = !0;
        a.listener = null;
        a.proxy = null;
        a.src = null;
        a.R = null
    };

    function dc(a) {
        this.src = a;
        this.g = {};
        this.h = 0
    }
    dc.prototype.add = function(a, b, c, d, e) {
        var g = a.toString();
        a = this.g[g];
        a || (a = this.g[g] = [], this.h++);
        var f = ec(a, b, d, e); - 1 < f ? (b = a[f], c || (b.P = !1)) : (b = new bc(b, this.src, g, !!d, e), b.P = c, a.push(b));
        return b
    };

    function fc(a, b) {
        var c = b.type;
        c in a.g && Qa(a.g[c], b) && (cc(b), 0 == a.g[c].length && (delete a.g[c], a.h--))
    }

    function ec(a, b, c, d) {
        for (var e = 0; e < a.length; ++e) {
            var g = a[e];
            if (!g.M && g.listener == b && g.capture == !!c && g.R == d) return e
        }
        return -1
    };
    var gc = "closure_lm_" + (1E6 * Math.random() | 0),
        hc = {},
        ic = 0;

    function jc(a, b, c, d, e) {
        if (Array.isArray(b))
            for (var g = 0; g < b.length; g++) jc(a, b[g], c, d, e);
        else(d = Ba(d) ? !!d.capture : !!d, c = kc(c), a && a[$b]) ? (a = a.i, b = String(b).toString(), b in a.g && (g = a.g[b], c = ec(g, c, d, e), -1 < c && (cc(g[c]), Array.prototype.splice.call(g, c, 1), 0 == g.length && (delete a.g[b], a.h--)))) : a && (a = lc(a)) && (b = a.g[b.toString()], a = -1, b && (a = ec(b, c, d, e)), (c = -1 < a ? b[a] : null) && "number" !== typeof c && c && !c.M && ((e = c.src) && e[$b] ? fc(e.i, c) : (d = c.type, b = c.proxy, e.removeEventListener ? e.removeEventListener(d, b, c.capture) :
            e.detachEvent ? e.detachEvent(d in hc ? hc[d] : hc[d] = "on" + d, b) : e.addListener && e.removeListener && e.removeListener(b), ic--, (d = lc(e)) ? (fc(d, c), 0 == d.h && (d.src = null, e[gc] = null)) : cc(c))))
    }

    function lc(a) {
        a = a[gc];
        return a instanceof dc ? a : null
    }
    var mc = "__closure_events_fn_" + (1E9 * Math.random() >>> 0);

    function kc(a) {
        if ("function" === typeof a) return a;
        a[mc] || (a[mc] = function(b) {
            return a.handleEvent(b)
        });
        return a[mc]
    };

    function U() {
        T.call(this);
        this.i = new dc(this);
        this.Y = this;
        this.J = null
    }
    Ea(U, T);
    U.prototype[$b] = !0;
    U.prototype.removeEventListener = function(a, b, c, d) {
        jc(this, a, b, c, d)
    };

    function V(a, b) {
        var c = a.J;
        if (c) {
            var d = [];
            for (var e = 1; c; c = c.J) d.push(c), ++e
        }
        a = a.Y;
        c = b.type || b;
        "string" === typeof b ? b = new Zb(b, a) : b instanceof Zb ? b.target = b.target || a : (e = b, b = new Zb(c, a), Nb(b, e));
        e = !0;
        if (d)
            for (var g = d.length - 1; 0 <= g; g--) {
                var f = b.g = d[g];
                e = nc(f, c, !0, b) && e
            }
        f = b.g = a;
        e = nc(f, c, !0, b) && e;
        e = nc(f, c, !1, b) && e;
        if (d)
            for (g = 0; g < d.length; g++) f = b.g = d[g], e = nc(f, c, !1, b) && e
    }
    U.prototype.K = function() {
        U.S.K.call(this);
        if (this.i) {
            var a = this.i,
                b = 0,
                c;
            for (c in a.g) {
                for (var d = a.g[c], e = 0; e < d.length; e++) ++b, cc(d[e]);
                delete a.g[c];
                a.h--
            }
        }
        this.J = null
    };

    function nc(a, b, c, d) {
        b = a.i.g[String(b)];
        if (!b) return !0;
        b = b.concat();
        for (var e = !0, g = 0; g < b.length; ++g) {
            var f = b[g];
            if (f && !f.M && f.capture == c) {
                var h = f.listener,
                    k = f.R || f.src;
                f.P && fc(a.i, f);
                e = !1 !== h.call(k, d) && e
            }
        }
        return e && !d.defaultPrevented
    };

    function oc(a) {
        try {
            return B.JSON.parse(a)
        } catch (b) {}
        a = String(a);
        if (/^\s*$/.test(a) ? 0 : /^[\],:{}\s\u2028\u2029]*$/.test(a.replace(/\\["\\\/bfnrtu]/g, "@").replace(/(?:"[^"\\\n\r\u2028\u2029\x00-\x08\x0a-\x1f]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)[\s\u2028\u2029]*(?=:|,|]|}|$)/g, "]").replace(/(?:^|:|,)(?:[\s\u2028\u2029]*\[)+/g, ""))) try {
            return eval("(" + a + ")")
        } catch (b) {}
        throw Error("Invalid JSON string: " + a);
    };

    function pc() {}
    pc.prototype.g = null;

    function qc(a) {
        var b;
        (b = a.g) || (b = {}, rc(a) && (b[0] = !0, b[1] = !0), b = a.g = b);
        return b
    };
    var sc;

    function tc() {}
    Ea(tc, pc);

    function uc(a) {
        return (a = rc(a)) ? new ActiveXObject(a) : new XMLHttpRequest
    }

    function rc(a) {
        if (!a.h && "undefined" == typeof XMLHttpRequest && "undefined" != typeof ActiveXObject) {
            for (var b = ["MSXML2.XMLHTTP.6.0", "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP", "Microsoft.XMLHTTP"], c = 0; c < b.length; c++) {
                var d = b[c];
                try {
                    return new ActiveXObject(d), a.h = d
                } catch (e) {}
            }
            throw Error("Could not create ActiveXObject. ActiveX might be disabled, or MSXML might not be installed");
        }
        return a.h
    }
    sc = new tc;

    function vc(a, b, c) {
        if ("function" === typeof a) c && (a = C(a, c));
        else if (a && "function" == typeof a.handleEvent) a = C(a.handleEvent, a);
        else throw Error("Invalid listener argument");
        return 2147483647 < Number(b) ? -1 : B.setTimeout(a, b || 0)
    };
    var wc = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function xc(a) {
        U.call(this);
        this.headers = new Map;
        this.C = a || null;
        this.h = !1;
        this.F = this.g = null;
        this.I = "";
        this.j = this.H = this.s = this.G = !1;
        this.D = 0;
        this.B = null;
        this.T = "";
        this.N = this.O = !1
    }
    Ea(xc, U);
    var yc = /^https?$/i,
        zc = ["POST", "PUT"],
        Ac = [];

    function Bc(a, b) {
        var c = new xc;
        Ac.push(c);
        b && c.i.add("complete", b, !1, void 0, void 0);
        c.i.add("ready", c.Z, !0, void 0, void 0);
        c.D = 2E3;
        c.O = !0;
        Cc(c, a)
    }
    p = xc.prototype;
    p.Z = function() {
        this.m || (this.m = !0, this.K());
        Qa(Ac, this)
    };

    function Cc(a, b) {
        var c = {};
        if (a.g) throw Error("[goog.net.XhrIo] Object is active with another request=" + a.I + "; newUri=" + b);
        a.I = b;
        a.G = !1;
        a.h = !0;
        a.g = a.C ? uc(a.C) : uc(sc);
        a.F = a.C ? qc(a.C) : qc(sc);
        a.g.onreadystatechange = C(a.V, a);
        try {
            a.H = !0, a.g.open("GET", String(b), !0), a.H = !1
        } catch (g) {
            Dc(a);
            return
        }
        b = new Map(a.headers);
        if (c)
            if (Object.getPrototypeOf(c) === Object.prototype)
                for (var d in c) b.set(d, c[d]);
            else if ("function" === typeof c.keys && "function" === typeof c.get) {
            d = u(c.keys());
            for (var e = d.next(); !e.done; e = d.next()) e =
                e.value, b.set(e, c.get(e))
        } else throw Error("Unknown input type for opt_headers: " + String(c));
        c = Array.from(b.keys()).find(function(g) {
            return "content-type" == g.toLowerCase()
        });
        d = B.FormData && !1;
        !(0 <= Oa(zc, "GET")) || c || d || b.set("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
        b = u(b);
        for (c = b.next(); !c.done; c = b.next()) d = u(c.value), c = d.next().value, d = d.next().value, a.g.setRequestHeader(c, d);
        a.T && (a.g.responseType = a.T);
        "withCredentials" in a.g && a.g.withCredentials !== a.O && (a.g.withCredentials =
            a.O);
        try {
            Ec(a), 0 < a.D && (a.N = Fc(a.g), a.N ? (a.g.timeout = a.D, a.g.ontimeout = C(a.X, a)) : a.B = vc(a.X, a.D, a)), a.s = !0, a.g.send(""), a.s = !1
        } catch (g) {
            Dc(a)
        }
    }

    function Fc(a) {
        return Sa && "number" === typeof a.timeout && void 0 !== a.ontimeout
    }
    p.X = function() {
        "undefined" != typeof ya && this.g && (V(this, "timeout"), this.abort(8))
    };

    function Dc(a) {
        a.h = !1;
        a.g && (a.j = !0, a.g.abort(), a.j = !1);
        Gc(a);
        Hc(a)
    }

    function Gc(a) {
        a.G || (a.G = !0, V(a, "complete"), V(a, "error"))
    }
    p.abort = function() {
        this.g && this.h && (this.h = !1, this.j = !0, this.g.abort(), this.j = !1, V(this, "complete"), V(this, "abort"), Hc(this))
    };
    p.K = function() {
        this.g && (this.h && (this.h = !1, this.j = !0, this.g.abort(), this.j = !1), Hc(this, !0));
        xc.S.K.call(this)
    };
    p.V = function() {
        this.isDisposed() || (this.H || this.s || this.j ? Ic(this) : this.da())
    };
    p.da = function() {
        Ic(this)
    };

    function Ic(a) {
        if (a.h && "undefined" != typeof ya && (!a.F[1] || 4 != (a.g ? a.g.readyState : 0) || 2 != Jc(a)))
            if (a.s && 4 == (a.g ? a.g.readyState : 0)) vc(a.V, 0, a);
            else if (V(a, "readystatechange"), 4 == (a.g ? a.g.readyState : 0)) {
            a.h = !1;
            try {
                var b = Jc(a);
                a: switch (b) {
                    case 200:
                    case 201:
                    case 202:
                    case 204:
                    case 206:
                    case 304:
                    case 1223:
                        var c = !0;
                        break a;
                    default:
                        c = !1
                }
                var d;
                if (!(d = c)) {
                    var e;
                    if (e = 0 === b) {
                        var g = String(a.I).match(wc)[1] || null;
                        !g && B.self && B.self.location && (g = B.self.location.protocol.slice(0, -1));
                        e = !yc.test(g ? g.toLowerCase() : "")
                    }
                    d =
                        e
                }
                d ? (V(a, "complete"), V(a, "success")) : Gc(a)
            } finally {
                Hc(a)
            }
        }
    }

    function Hc(a, b) {
        if (a.g) {
            Ec(a);
            var c = a.g,
                d = a.F[0] ? function() {} : null;
            a.g = null;
            a.F = null;
            b || V(a, "ready");
            try {
                c.onreadystatechange = d
            } catch (e) {}
        }
    }

    function Ec(a) {
        a.g && a.N && (a.g.ontimeout = null);
        a.B && (B.clearTimeout(a.B), a.B = null)
    }
    p.isActive = function() {
        return !!this.g
    };

    function Jc(a) {
        try {
            return 2 < (a.g ? a.g.readyState : 0) ? a.g.status : -1
        } catch (b) {
            return -1
        }
    };
    /*

     SPDX-License-Identifier: Apache-2.0
    */
    var Kc;
    try {
        new URL("s://g"), Kc = !0
    } catch (a) {
        Kc = !1
    }
    var Lc = Kc;

    function Mc(a) {
        var b = va.apply(1, arguments);
        if (0 === b.length) return Rb(a[0]);
        for (var c = a[0], d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return Rb(c)
    };

    function Nc(a) {
        this.ca = a
    }

    function W(a) {
        return new Nc(function(b) {
            return b.substr(0, a.length + 1).toLowerCase() === a + ":"
        })
    }
    var Oc = [W("data"), W("http"), W("https"), W("mailto"), W("ftp"), new Nc(function(a) {
        return /^[^:]*([/?#]|$)/.test(a)
    })];

    function Pc(a) {
        var b = void 0 === b ? Oc : b;
        a: {
            b = void 0 === b ? Oc : b;
            for (var c = 0; c < b.length; ++c) {
                var d = b[c];
                if (d instanceof Nc && d.ca(a)) {
                    a = new S(a, Sb);
                    break a
                }
            }
            a = void 0
        }
        return a || Tb
    };

    function Qc(a, b) {
        a.src = b instanceof Pb && b.constructor === Pb ? b.g : "type_error:TrustedResourceUrl";
        var c, d;
        (c = (b = null == (d = (c = (a.ownerDocument && a.ownerDocument.defaultView || window).document).querySelector) ? void 0 : d.call(c, "script[nonce]")) ? b.nonce || b.getAttribute("nonce") || "" : "") && a.setAttribute("nonce", c)
    };

    function Rc(a, b) {
        if (b instanceof S) b = b instanceof S && b.constructor === S ? b.g : "type_error:SafeUrl";
        else {
            b: if (Lc) {
                try {
                    var c = new URL(b)
                } catch (d) {
                    c = "https:";
                    break b
                }
                c = c.protocol
            } else c: {
                c = document.createElement("a");
                try {
                    c.href = b
                } catch (d) {
                    c = void 0;
                    break c
                }
                c = c.protocol;c = ":" === c || "" === c ? "https:" : c
            }
            b = "javascript:" !== c ? b : void 0
        }
        void 0 !== b && a.open(b, void 0, void 0)
    };

    function X(a) {
        this.l = Bb(a)
    }
    ma(X, R);
    p = X.prototype;
    p.getEnableSsEngine = function() {
        return Q(this, 2)
    };
    p.getEnableAwr = function() {
        return Q(this, 3)
    };
    p.getEnableHelpSuggestions = function() {
        return Q(this, 4)
    };
    p.getAlohaAutoGaRollout = function() {
        return Q(this, 5)
    };
    p.getEnableConfigurator = function() {
        return Q(this, 6)
    };
    p.getEnableMweb = function() {
        return Q(this, 7)
    };
    p.getEnableCtlConsentCheckbox = function() {
        return Q(this, 8)
    };
    p.getEnableIframe = function() {
        return Q(this, 9)
    };
    p.getEnableScreenshotNudge = function() {
        return Q(this, 10)
    };
    p.getEnableWebStartupConfigEndpoint = function() {
        return Q(this, 11)
    };
    p.getEnableJunkNudge = function() {
        return Q(this, 12)
    };
    p.getEnableConfiguratorLocale = function() {
        return Q(this, 13)
    };
    p.getEnableTinyNoPointer = function() {
        return Q(this, 14)
    };
    p.getEnableSupportSessionLogging = function() {
        return Q(this, 15)
    };
    p.getEnableFileUploadForScreenshot = function() {
        return Q(this, 16)
    };
    p.getEnableDirectDeflectionForSingleCategory = function() {
        return Q(this, 17)
    };
    p.getEnableImageSanitization = function() {
        return Q(this, 18)
    };
    p.getEnableAlohaBinarySplit = function() {
        return Q(this, 19)
    };
    p.getEnableDbFeedbackIntents = function() {
        return Q(this, 20)
    };
    p.getEnableMarkMandatoryFieldsWithRequired = function() {
        return Q(this, 21)
    };
    p.getEnableFeedbackCategoryCustomUi = function() {
        return Q(this, 22)
    };

    function Sc(a) {
        this.l = Bb(a)
    }
    ma(Sc, R);

    function Tc(a) {
        return Uc.some(function(b) {
            return b.test(a)
        })
    }
    var Uc = [/https:\/\/sandbox\.google\.com\/tools\/feedback/, /https:\/\/feedback-frontend-qual[a-z0-9.]*\.google\.com\/inapp/, /https:\/\/feedback-frontend-qual[a-z0-9.]*\.google\.com\/tools\/feedback/, /https:\/\/.*\.googleusercontent\.com\/inapp/];
    var Vc = "af;am;ar-EG;ar-JO;ar-MA;ar-SA;ar-XB;ar;az;be;bg;bn;bs;ca;cs;cy;da;de-AT;de-CH;de;el;en;en-GB;en-AU;en-CA;en-IE;en-IN;en-NZ;en-SG;en-XA;en-XC;en-ZA;es;es-419;es-AR;es-BO;es-CL;es-CO;es-CR;es-DO;es-EC;es-GT;es-HN;es-MX;es-NI;es-PA;es-PE;es-PR;es-PY;es-SV;es-US;es-UY;es-VE;et;eu;fa;fi;fil;fr-CA;fr-CH;fr;gl;gsw;gu;he;hi;hr;hu;hy;id;in;is;it;iw;ja;ka;kk;km;kn;ko;ky;ln;lo;lt;lv;mk;ml;mn;mo;mr;ms;my;nb;ne;nl;no;pa;pl;pt;pt-BR;pt-PT;ro;ru;si;sk;sl;sq;sr-Latn;sr;sv;sw;ta;te;th;tl;tr;uk ; ur ; uz ; vi ; zh;zh-CN;zh-HK;zh-TW;zu".split(";");

    function Wc(a) {
        var b;
        return null == (b = a.formContent) ? void 0 : b.locale
    };
    var Xc = ea(["https://www.gstatic.com/uservoice/feedback/client/web/", "/main_light_binary.js"]),
        Yc = ea(["https://www.gstatic.com/uservoice/feedback/client/web/", "/main_binary__", ".js"]);

    function Zc(a, b) {
        var c = Wc(a);
        c = (c && Vc.includes(c) ? Wc(a) : "en").replaceAll("-", "_").toLowerCase();
        var d;
        a = (null == (d = a.initializationData) ? 0 : d.useNightlyRelease) ? "nightly" : "live";
        var e;
        return (null == b ? 0 : null == (e = b.getEnableAlohaBinarySplit) ? 0 : e.call(b)) ? Mc(Xc, a) : Mc(Yc, a, c)
    };
    var $c, ad;

    function bd(a, b, c, d) {
        if ($c) return $c;
        var e = Zc(a, d);
        return $c = b.feedbackV2GlobalObject ? Promise.resolve(b.feedbackV2GlobalObject) : new Promise(function(g, f) {
            var h = Xb(document);
            Qc(h, e);
            h.onload = function() {
                b.feedbackV2GlobalObject ? g(b.feedbackV2GlobalObject) : f("feedbackV2GlobalObject not found on window.")
            };
            h.onerror = function() {
                f("Feedback binary script tag failed to load: " + e.toString())
            };
            c.body.appendChild(h)
        })
    }

    function cd(a, b, c, d) {
        if (ad) return ad;
        var e = Zc(a, d);
        return ad = b.feedbackV2GlobalObject ? Promise.resolve(b.feedbackV2GlobalObject) : new Promise(function(g, f) {
            var h = Xb(document);
            Qc(h, e);
            h.onload = function() {
                b.feedbackV2GlobalObject ? g(b.feedbackV2GlobalObject) : f("feedbackV2GlobalObject not found on window.")
            };
            h.onerror = function() {
                f("Feedback binary script tag failed to load: " + e.toString())
            };
            c.body.appendChild(h)
        })
    }

    function dd(a, b, c, d, e) {
        e = void 0 === e ? !0 : e;
        var g, f, h, k, l;
        return y(function(m) {
            switch (m.g) {
                case 1:
                    return g = Date.now(), v(m, bd(a, c, d, b), 2);
                case 2:
                    f = m.i;
                    if (!(e || (null == (k = a.initializationData) ? 0 : k.useNightlyRelease) || (null == (l = a.initializationData) ? 0 : l.isLocalServer))) {
                        h = f.initializeFeedbackClient(a, g, b);
                        m.g = 3;
                        break
                    }
                    return v(m, f.initializeFeedbackClientAsync(a, g, b), 4);
                case 4:
                    h = m.i;
                case 3:
                    return h.initiateAloha(), m.return(h)
            }
        })
    }

    function ed(a, b, c, d) {
        var e, g, f;
        return y(function(h) {
            if (1 == h.g) return e = Date.now(), v(h, cd(a, c, d.document, b), 2);
            if (3 != h.g) return g = h.i, v(h, g.initializeFeedbackClientAsync(a, e, b, d), 3);
            f = h.i;
            f.initiateAloha();
            return h.return(f)
        })
    }

    function fd(a, b, c) {
        var d = !0;
        d = void 0 === d ? !0 : d;
        var e, g, f, h, k, l, m, n, t, w;
        return y(function(M) {
            e = c || B;
            if (null == (g = b) ? 0 : null == (h = (f = g).getEnableAlohaBinarySplit) ? 0 : h.call(f)) {
                k = e;
                if (k.isFormOpened) throw l = Error("Form is either loading or already opened"), l.name = "DuplicateFormError", l;
                k.isFormOpened = !0;
                a.callbacks = a.callbacks || {};
                m = a.callbacks.onClose || function() {};
                a.callbacks.onClose = function(z) {
                    k.isFormOpened = !1;
                    m(z)
                };
                try {
                    return M.return(ed(a, b, k, e))
                } catch (z) {
                    throw k.isFormOpened = !1, z;
                }
            } else {
                n = e;
                if (n.isFormOpened) throw t =
                    Error("Form is either loading or already opened"), t.name = "DuplicateFormError", t;
                n.isFormOpened = !0;
                a.callbacks = a.callbacks || {};
                w = a.callbacks.onClose || function() {};
                a.callbacks.onClose = function(z) {
                    n.isFormOpened = !1;
                    w(z)
                };
                try {
                    return M.return(dd(a, b, n, e.document, d))
                } catch (z) {
                    throw n.isFormOpened = !1, z;
                }
            }
        })
    };

    function gd(a, b) {
        return y(function(c) {
            return c.return(new Promise(function(d) {
                var e = hd(null != b ? b : "") + "/aloha_form_properties?productId=" + a;
                Bc(e, function(g) {
                    var f = g.target;
                    g = null;
                    try {
                        var h = JSON,
                            k = h.stringify;
                        if (f.g) {
                            var l = f.g.responseText;
                            0 == l.indexOf(")]}'\n") && (l = l.substring(5));
                            b: {
                                if (B.JSON) try {
                                    var m = B.JSON.parse(l);
                                    break b
                                } catch (w) {}
                                m = oc(l)
                            }
                        } else m = void 0;
                        var n = k.call(h, m);
                        if (null == n || "" == n) g = new Sc;
                        else {
                            var t = JSON.parse(n);
                            if (!Array.isArray(t)) throw Error(void 0);
                            kb(t, 16);
                            g = Ab(Sc, t)
                        }
                    } catch (w) {
                        k =
                            new Sc;
                        m = new X;
                        m = P(m, 5, !0);
                        m = P(m, 2, !0);
                        m = P(m, 4, !1);
                        m = P(m, 8, !0);
                        m = P(m, 9, !0);
                        m = P(m, 7, !0);
                        m = P(m, 10, !0);
                        m = P(m, 12, !0);
                        m = P(m, 13, !1);
                        m = P(m, 14, !0);
                        m = P(m, 15, !0);
                        m = P(m, 20, !1);
                        if (null != m) {
                            if (!(m instanceof X)) throw Error("Expected instanceof " + sb(X) + " but got " + (m && sb(m.constructor)));
                        } else m = void 0;
                        n = k.l;
                        t = K(n);
                        if (t & 2) throw Error();
                        yb(n, t, 1, m);
                        g = k
                    }
                    d(g)
                })
            }))
        })
    }

    function hd(a) {
        return Tc(a) ? a : "https://www.google.com/tools/feedback"
    };

    function id(a, b, c) {
        a.timeOfStartCall = (new Date).getTime();
        var d = c || B,
            e = d.document,
            g = a.nonce || Vb(d);
        g && !a.nonce && (a.nonce = g);
        if ("help" == a.flow) {
            var f = za("document.location.href", d);
            !a.helpCenterContext && f && (a.helpCenterContext = f.substring(0, 1200));
            f = !0;
            if (b && JSON && JSON.stringify) {
                var h = JSON.stringify(b);
                (f = 1200 >= h.length) && (a.psdJson = h)
            }
            f || (b = {
                invalidPsd: !0
            })
        }
        b = [a, b, c];
        d.GOOGLE_FEEDBACK_START_ARGUMENTS = b;
        c = a.feedbackServerUri || "//www.google.com/tools/feedback";
        if (f = d.GOOGLE_FEEDBACK_START) f.apply(d,
            b);
        else {
            d = c + "/load.js?";
            for (var k in a) b = a[k], null == b || Ba(b) || (d += encodeURIComponent(k) + "=" + encodeURIComponent(b) + "&");
            a = e ? new Yb(9 == e.nodeType ? e : e.ownerDocument || e.document) : Ga || (Ga = new Yb);
            a = Xb(a.g);
            g && a.setAttribute("nonce", g);
            g = Rb(d);
            Qc(a, g);
            e.body.appendChild(a)
        }
    }

    function jd(a, b, c, d) {
        var e, g;
        y(function(f) {
            e = c || B;
            var h = ["web_answers"].includes(a.triggerId) ? "en" : a.locale,
                k = "DEV" === a.serverEnvironment,
                l = c || B;
            l = a.nonce || Vb(l);
            h = {
                integrationKeys: {
                    productId: a.productId,
                    feedbackBucket: a.bucket,
                    triggerId: a.triggerId
                },
                callbacks: {
                    onClose: a.callback,
                    onLoad: a.onLoadCallback
                },
                formContent: {
                    locale: h,
                    disableScreenshot: a.disableScreenshotting,
                    productDisplayName: void 0,
                    announcement: void 0,
                    issueCategories: void 0,
                    includeSeveritySelection: void 0,
                    customImageSrc: void 0,
                    thankYouMessage: void 0,
                    pa: void 0,
                    defaultFormInputValues: void 0,
                    defaultFormInputValuesString: void 0,
                    abuseLink: a.abuseLink
                },
                initializationData: {
                    isLocalServer: k,
                    nonce: l,
                    useNightlyRelease: k,
                    feedbackJsUrl: void 0,
                    feedbackCssUrl: void 0,
                    feedbackJsUrlSerialized: void 0,
                    feedbackCssUrlSerialized: void 0,
                    submissionServerUri: a.feedbackServerUri,
                    colorScheme: a.colorScheme
                },
                extraData: {
                    productVersion: a.productVersion,
                    authUser: a.authuser,
                    configuratorId: a.configuratorId,
                    customZIndex: a.customZIndex,
                    tinyNoPointer: a.tinyNoPointer,
                    allowNonLoggedInFeedback: a.allowNonLoggedInFeedback,
                    enableAnonymousFeedback: a.enableAnonymousFeedback
                }
            };
            b && (k = new Map(Object.entries(b)), h.extraData.productSpecificData = k);
            g = h;
            return v(f, fd(g, d, e), 0)
        })
    }

    function kd(a, b, c) {
        try {
            if ("help" === a.flow) {
                var d = a.helpCenterPath.replace(/^\//, "");
                Rc(c || window, Pc("https://support.google.com/" + d))
            } else "submit" === a.flow ? id(a, b, c) : gd(a.productId, a.feedbackServerUri).then(function(e) {
                var g = void 0 === g ? !1 : g;
                var f = e.l;
                var h = K(f),
                    k = xb(f, h, 1, g);
                var l = !1;
                if (null == k || "object" !== typeof k || (l = Array.isArray(k)) || k.A !== L)
                    if (l) {
                        var m = l = I(k);
                        0 === m && (m |= h & 16);
                        m |= h & 2;
                        m !== l && J(k, m);
                        l = new X(k)
                    } else l = void 0;
                else l = k;
                l !== k && null != l && yb(f, h, 1, l, g);
                f = l;
                null != f && (e = e.l, h = K(e), h & 2 ||
                    (k = f, K(k.l) & 2 && (l = Jb(k, !1), l.U = k, kb(l.l, 512), k = l), k !== f && (f = k, yb(e, h, 1, f, g))));
                g = f;
                e = !Ta || (null == g ? void 0 : g.getEnableMweb());
                f = !a.tinyNoPointer || (null == g ? void 0 : g.getEnableTinyNoPointer());
                !g || g.getAlohaAutoGaRollout() && e && f ? jd(a, b, c, g) : id(a, b, c)
            }, function(e) {
                e && "DuplicateFormError" !== e.name && id(a, b, c)
            })
        } catch (e) {
            jd(a, b, c, null)
        }
    }
    var ld = ["userfeedback", "api", "startFeedback"],
        Y = B;
    ld[0] in Y || "undefined" == typeof Y.execScript || Y.execScript("var " + ld[0]);
    for (var Z; ld.length && (Z = ld.shift());) ld.length || void 0 === kd ? Y[Z] && Y[Z] !== Object.prototype[Z] ? Y = Y[Z] : Y = Y[Z] = {} : Y[Z] = kd;
}).call(this);